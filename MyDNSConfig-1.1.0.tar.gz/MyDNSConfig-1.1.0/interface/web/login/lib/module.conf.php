<?php
$module["name"] 		= "login";
$module["title"] 		= "Login";
$module["template"] 	= "module.tpl.htm";
$module["startpage"] 	= "login/index.php";
?>