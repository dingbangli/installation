<?php

/*
	Datentypen:
	- INTEGER (Wandelt Ausdr�cke in Int um)
	- DOUBLE
	- CURRENCY (Formatiert Zahlen nach W�hrungsnotation)
	- VARCHAR (kein weiterer Format Check)
	- TEXT (kein weiterer Format Check)
	- DATE (Datumsformat, Timestamp Umwandlung)
*/



// Name der Liste
$liste["name"] 				= "groups";

// Datenbank Tabelle
$liste["table"] 			= "sys_group";

// Index Feld der datenbank
$liste["table_idx"]			= "groupid";

// Search Field Prefix
$liste["search_prefix"] 	= "search_";

// Eintr�ge pro Seite
$liste["records_per_page"] 	= 15;

// Script File der Liste
$liste["file"]				= "groups_list.php";

// Script File der Liste
$liste["edit_file"]			= "groups_edit.php";

// Script File der Liste
$liste["delete_file"]		= "groups_del.php";

// Paging Template
$liste["paging_tpl"]		= "templates/paging.tpl.htm";

// Script File der Liste
$liste["auth"]				= "no";


/*****************************************************
* Suchfelder
*****************************************************/

$liste["item"][] = array(	'field'		=> "name",
							'datatype'	=> "VARCHAR",
							'op'		=> "like",
							'prefix'	=> "%",
							'suffix'	=> "%",
							'width'		=> "");

$liste["item"][] = array(	'field'		=> "description",
							'datatype'	=> "VARCHAR",
							'op'		=> "like",
							'prefix'	=> "%",
							'suffix'	=> "%",
							'width'		=> "");  



?>